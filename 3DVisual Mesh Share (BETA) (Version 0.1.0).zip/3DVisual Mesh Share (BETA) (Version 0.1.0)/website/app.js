const LINKS = {
  repo: "https://github.com/your-name/3dvisual-mesh",
  releases: "https://github.com/your-name/3dvisual-mesh/releases",
  downloadZip: "https://github.com/your-name/3dvisual-mesh/releases/latest",
  issues: "https://github.com/your-name/3dvisual-mesh/issues",
  discussions: "https://github.com/your-name/3dvisual-mesh/discussions",
  space: "https://huggingface.co/spaces/your-name/3dvisual-mesh-demo",
};

for (const node of document.querySelectorAll("[data-link]")) {
  const key = node.getAttribute("data-link");
  const href = LINKS[key];
  if (!href) {
    continue;
  }
  node.setAttribute("href", href);
  node.setAttribute("target", "_blank");
  node.setAttribute("rel", "noreferrer");
}
