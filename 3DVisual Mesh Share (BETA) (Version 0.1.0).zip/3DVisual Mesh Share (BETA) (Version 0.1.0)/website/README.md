# 3DVisual Mesh Website

This folder is a simple static website for the public open-source project page.

## Best choice

Use this site as the public landing page, and keep the Windows app downloads in GitHub Releases.

## Why

- easiest public setup
- simple to deploy
- good for screenshots, docs, buttons, roadmap, installer downloads, and portable zip downloads
- no need to host the full AI generator in the website itself on day one

## What to edit first

1. Open `website/app.js`
2. Replace the placeholder GitHub and Hugging Face links
3. Deploy `website/` to your static host

## Best hosting path

- Best: Cloudflare Pages for the website + GitHub Releases for downloads
- Second best: GitHub Pages for the website + GitHub Releases for downloads
- Demo later: Hugging Face Spaces for an online AI demo

## Official docs

- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages
- Cloudflare Pages: https://developers.cloudflare.com/pages/get-started/
- Hugging Face Spaces: https://huggingface.co/docs/hub/spaces
- Vercel getting started: https://vercel.com/docs/getting-started-with-vercel
